/* IMPORTANT: EDIT m_dispatch_gen.c INSTEAD OF THIS FILE */

typedef void (*t_vfun00)(void);
typedef void (*t_vfun01)(t_floatarg d0);
typedef void (*t_vfun10)(t_int i0);
typedef void (*t_vfun02)(t_floatarg d0, t_floatarg d1);
typedef void (*t_vfun11)(t_int i0, t_floatarg d0);
typedef void (*t_vfun20)(t_int i0, t_int i1);
typedef void (*t_vfun03)(t_floatarg d0, t_floatarg d1, t_floatarg d2);
typedef void (*t_vfun12)(t_int i0, t_floatarg d0, t_floatarg d1);
typedef void (*t_vfun21)(t_int i0, t_int i1, t_floatarg d0);
typedef void (*t_vfun30)(t_int i0, t_int i1, t_int i2);
typedef void (*t_vfun04)(t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3);
typedef void (*t_vfun13)(t_int i0, t_floatarg d0, t_floatarg d1, t_floatarg d2);
typedef void (*t_vfun22)(t_int i0, t_int i1, t_floatarg d0, t_floatarg d1);
typedef void (*t_vfun31)(t_int i0, t_int i1, t_int i2, t_floatarg d0);
typedef void (*t_vfun40)(t_int i0, t_int i1, t_int i2, t_int i3);
typedef void (*t_vfun05)(t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3, t_floatarg d4);
typedef void (*t_vfun14)(t_int i0, t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3);
typedef void (*t_vfun23)(t_int i0, t_int i1, t_floatarg d0, t_floatarg d1, t_floatarg d2);
typedef void (*t_vfun32)(t_int i0, t_int i1, t_int i2, t_floatarg d0, t_floatarg d1);
typedef void (*t_vfun41)(t_int i0, t_int i1, t_int i2, t_int i3, t_floatarg d0);
typedef void (*t_vfun50)(t_int i0, t_int i1, t_int i2, t_int i3, t_int i4);
typedef void (*t_vfun06)(t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3, t_floatarg d4, t_floatarg d5);
typedef void (*t_vfun15)(t_int i0, t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3, t_floatarg d4);
typedef void (*t_vfun24)(t_int i0, t_int i1, t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3);
typedef void (*t_vfun33)(t_int i0, t_int i1, t_int i2, t_floatarg d0, t_floatarg d1, t_floatarg d2);
typedef void (*t_vfun42)(t_int i0, t_int i1, t_int i2, t_int i3, t_floatarg d0, t_floatarg d1);
typedef void (*t_vfun51)(t_int i0, t_int i1, t_int i2, t_int i3, t_int i4, t_floatarg d0);
typedef void (*t_vfun60)(t_int i0, t_int i1, t_int i2, t_int i3, t_int i4, t_int i5);
typedef t_pd *(*t_fun00)(void);
typedef t_pd *(*t_fun01)(t_floatarg d0);
typedef t_pd *(*t_fun10)(t_int i0);
typedef t_pd *(*t_fun02)(t_floatarg d0, t_floatarg d1);
typedef t_pd *(*t_fun11)(t_int i0, t_floatarg d0);
typedef t_pd *(*t_fun20)(t_int i0, t_int i1);
typedef t_pd *(*t_fun03)(t_floatarg d0, t_floatarg d1, t_floatarg d2);
typedef t_pd *(*t_fun12)(t_int i0, t_floatarg d0, t_floatarg d1);
typedef t_pd *(*t_fun21)(t_int i0, t_int i1, t_floatarg d0);
typedef t_pd *(*t_fun30)(t_int i0, t_int i1, t_int i2);
typedef t_pd *(*t_fun04)(t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3);
typedef t_pd *(*t_fun13)(t_int i0, t_floatarg d0, t_floatarg d1, t_floatarg d2);
typedef t_pd *(*t_fun22)(t_int i0, t_int i1, t_floatarg d0, t_floatarg d1);
typedef t_pd *(*t_fun31)(t_int i0, t_int i1, t_int i2, t_floatarg d0);
typedef t_pd *(*t_fun40)(t_int i0, t_int i1, t_int i2, t_int i3);
typedef t_pd *(*t_fun05)(t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3, t_floatarg d4);
typedef t_pd *(*t_fun14)(t_int i0, t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3);
typedef t_pd *(*t_fun23)(t_int i0, t_int i1, t_floatarg d0, t_floatarg d1, t_floatarg d2);
typedef t_pd *(*t_fun32)(t_int i0, t_int i1, t_int i2, t_floatarg d0, t_floatarg d1);
typedef t_pd *(*t_fun41)(t_int i0, t_int i1, t_int i2, t_int i3, t_floatarg d0);
typedef t_pd *(*t_fun50)(t_int i0, t_int i1, t_int i2, t_int i3, t_int i4);
typedef t_pd *(*t_fun06)(t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3, t_floatarg d4, t_floatarg d5);
typedef t_pd *(*t_fun15)(t_int i0, t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3, t_floatarg d4);
typedef t_pd *(*t_fun24)(t_int i0, t_int i1, t_floatarg d0, t_floatarg d1, t_floatarg d2, t_floatarg d3);
typedef t_pd *(*t_fun33)(t_int i0, t_int i1, t_int i2, t_floatarg d0, t_floatarg d1, t_floatarg d2);
typedef t_pd *(*t_fun42)(t_int i0, t_int i1, t_int i2, t_int i3, t_floatarg d0, t_floatarg d1);
typedef t_pd *(*t_fun51)(t_int i0, t_int i1, t_int i2, t_int i3, t_int i4, t_floatarg d0);
typedef t_pd *(*t_fun60)(t_int i0, t_int i1, t_int i2, t_int i3, t_int i4, t_int i5);

static void mess_dispatch(t_pd *x, t_gotfn fn, int niarg, t_int *ai,
    int nfarg, t_floatarg *ad)
{
    if (x == &pd_objectmaker)
    {
        t_pd *ret;
        switch (niarg * 16 + nfarg)
        {
        case 0x00 : ret = (*(t_fun00)fn)(); break;
        case 0x01 : ret = (*(t_fun01)fn)(ad[0]); break;
        case 0x10 : ret = (*(t_fun10)fn)(ai[0]); break;
        case 0x02 : ret = (*(t_fun02)fn)(ad[0], ad[1]); break;
        case 0x11 : ret = (*(t_fun11)fn)(ai[0], ad[0]); break;
        case 0x20 : ret = (*(t_fun20)fn)(ai[0], ai[1]); break;
        case 0x03 : ret = (*(t_fun03)fn)(ad[0], ad[1], ad[2]); break;
        case 0x12 : ret = (*(t_fun12)fn)(ai[0], ad[0], ad[1]); break;
        case 0x21 : ret = (*(t_fun21)fn)(ai[0], ai[1], ad[0]); break;
        case 0x30 : ret = (*(t_fun30)fn)(ai[0], ai[1], ai[2]); break;
        case 0x04 : ret = (*(t_fun04)fn)(ad[0], ad[1], ad[2], ad[3]); break;
        case 0x13 : ret = (*(t_fun13)fn)(ai[0], ad[0], ad[1], ad[2]); break;
        case 0x22 : ret = (*(t_fun22)fn)(ai[0], ai[1], ad[0], ad[1]); break;
        case 0x31 : ret = (*(t_fun31)fn)(ai[0], ai[1], ai[2], ad[0]); break;
        case 0x40 : ret = (*(t_fun40)fn)(ai[0], ai[1], ai[2], ai[3]); break;
        case 0x05 : ret = (*(t_fun05)fn)(ad[0], ad[1], ad[2], ad[3], ad[4]); break;
        case 0x14 : ret = (*(t_fun14)fn)(ai[0], ad[0], ad[1], ad[2], ad[3]); break;
        case 0x23 : ret = (*(t_fun23)fn)(ai[0], ai[1], ad[0], ad[1], ad[2]); break;
        case 0x32 : ret = (*(t_fun32)fn)(ai[0], ai[1], ai[2], ad[0], ad[1]); break;
        case 0x41 : ret = (*(t_fun41)fn)(ai[0], ai[1], ai[2], ai[3], ad[0]); break;
        case 0x50 : ret = (*(t_fun50)fn)(ai[0], ai[1], ai[2], ai[3], ai[4]); break;
        case 0x06 : ret = (*(t_fun06)fn)(ad[0], ad[1], ad[2], ad[3], ad[4], ad[5]); break;
        case 0x15 : ret = (*(t_fun15)fn)(ai[0], ad[0], ad[1], ad[2], ad[3], ad[4]); break;
        case 0x24 : ret = (*(t_fun24)fn)(ai[0], ai[1], ad[0], ad[1], ad[2], ad[3]); break;
        case 0x33 : ret = (*(t_fun33)fn)(ai[0], ai[1], ai[2], ad[0], ad[1], ad[2]); break;
        case 0x42 : ret = (*(t_fun42)fn)(ai[0], ai[1], ai[2], ai[3], ad[0], ad[1]); break;
        case 0x51 : ret = (*(t_fun51)fn)(ai[0], ai[1], ai[2], ai[3], ai[4], ad[0]); break;
        case 0x60 : ret = (*(t_fun60)fn)(ai[0], ai[1], ai[2], ai[3], ai[4], ai[5]); break;
        default : ret = 0; break;
        }
        pd_this->pd_newest = ret;
    }
    else
    {
        switch (niarg * 16 + nfarg)
        {
        case 0x00 : (*(t_vfun00)fn)(); break;
        case 0x01 : (*(t_vfun01)fn)(ad[0]); break;
        case 0x10 : (*(t_vfun10)fn)(ai[0]); break;
        case 0x02 : (*(t_vfun02)fn)(ad[0], ad[1]); break;
        case 0x11 : (*(t_vfun11)fn)(ai[0], ad[0]); break;
        case 0x20 : (*(t_vfun20)fn)(ai[0], ai[1]); break;
        case 0x03 : (*(t_vfun03)fn)(ad[0], ad[1], ad[2]); break;
        case 0x12 : (*(t_vfun12)fn)(ai[0], ad[0], ad[1]); break;
        case 0x21 : (*(t_vfun21)fn)(ai[0], ai[1], ad[0]); break;
        case 0x30 : (*(t_vfun30)fn)(ai[0], ai[1], ai[2]); break;
        case 0x04 : (*(t_vfun04)fn)(ad[0], ad[1], ad[2], ad[3]); break;
        case 0x13 : (*(t_vfun13)fn)(ai[0], ad[0], ad[1], ad[2]); break;
        case 0x22 : (*(t_vfun22)fn)(ai[0], ai[1], ad[0], ad[1]); break;
        case 0x31 : (*(t_vfun31)fn)(ai[0], ai[1], ai[2], ad[0]); break;
        case 0x40 : (*(t_vfun40)fn)(ai[0], ai[1], ai[2], ai[3]); break;
        case 0x05 : (*(t_vfun05)fn)(ad[0], ad[1], ad[2], ad[3], ad[4]); break;
        case 0x14 : (*(t_vfun14)fn)(ai[0], ad[0], ad[1], ad[2], ad[3]); break;
        case 0x23 : (*(t_vfun23)fn)(ai[0], ai[1], ad[0], ad[1], ad[2]); break;
        case 0x32 : (*(t_vfun32)fn)(ai[0], ai[1], ai[2], ad[0], ad[1]); break;
        case 0x41 : (*(t_vfun41)fn)(ai[0], ai[1], ai[2], ai[3], ad[0]); break;
        case 0x50 : (*(t_vfun50)fn)(ai[0], ai[1], ai[2], ai[3], ai[4]); break;
        case 0x06 : (*(t_vfun06)fn)(ad[0], ad[1], ad[2], ad[3], ad[4], ad[5]); break;
        case 0x15 : (*(t_vfun15)fn)(ai[0], ad[0], ad[1], ad[2], ad[3], ad[4]); break;
        case 0x24 : (*(t_vfun24)fn)(ai[0], ai[1], ad[0], ad[1], ad[2], ad[3]); break;
        case 0x33 : (*(t_vfun33)fn)(ai[0], ai[1], ai[2], ad[0], ad[1], ad[2]); break;
        case 0x42 : (*(t_vfun42)fn)(ai[0], ai[1], ai[2], ai[3], ad[0], ad[1]); break;
        case 0x51 : (*(t_vfun51)fn)(ai[0], ai[1], ai[2], ai[3], ai[4], ad[0]); break;
        case 0x60 : (*(t_vfun60)fn)(ai[0], ai[1], ai[2], ai[3], ai[4], ai[5]); break;
        default : break;
        }
    }
}
